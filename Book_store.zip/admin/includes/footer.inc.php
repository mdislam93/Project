<div id="footer-wrap">
	<p id="legal">Copyright Reserved@2022 Design by <a href="">Online Book Store</a>.</p>
	</div>